# coolicons

coolicons by Kryston Schwarze

License: CC BY 4.0
Repository: https://github.com/krystonschwarze/coolicons

## License

For the full license text, please visit: https://github.com/krystonschwarze/coolicons/blob/master/LICENSE